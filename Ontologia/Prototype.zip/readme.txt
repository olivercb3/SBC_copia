Com executar el prototip:

    Inicialització:

    >> (clear)
    >> (load "init.clp")
    >> (assert(initial))
    >> (run)

    Per fer una execució:

    >> (assert(initial-main))
    >> (run)